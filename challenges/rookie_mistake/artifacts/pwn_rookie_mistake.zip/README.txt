╔══════════════════════════════════════════════════════════════╗
║   🎃  Tips from w3th4nds: 👻                                   ║
╚══════════════════════════════════════════════════════════════╝


########################### 👻 CONNECTION 👻 ###########################

* Run the program locally : ./rookie_mistake
* Run the program remotely: nc <IP> <PORT> e.g. nc 127.0.0.1 1337


########################### 🕷️ HINTS 🕷️ ###########################

* A, not so, simple ret2win challenge.
* Overflow the buffer and call win (or a certain address of it...)

