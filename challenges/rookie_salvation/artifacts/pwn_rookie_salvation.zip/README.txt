╔══════════════════════════════════════════════════════════════╗
║   🎃  Tips from w3th4nds: 👻                                 ║
╚══════════════════════════════════════════════════════════════╝


########################### 👻 CONNECTION 👻 ###########################

* Run the program locally : ./rookie_salvation
* Run the program remotely: nc <IP> <PORT> e.g. nc 127.0.0.1 1337


########################### 🕷️ HINTS 🕷️ ###########################

* Just let it freeee....
* 0xdeadbeef? Nah, w3th4nds is better..
* How much to allocate? 20? 0x20? 0x2000000000000?
* Where is the offset to overwrite?
* ESCAPE